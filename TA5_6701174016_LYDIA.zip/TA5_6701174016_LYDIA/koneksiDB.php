<?php 
	$server		= "localhost";
	$user		= "root";
	$password	= "";
	$db_name	= "mahasiswa";

	$koneksi = mysqli_connect($server, $user, $password, $db_name);
 ?>